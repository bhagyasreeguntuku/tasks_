package service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import com.example.redis.redisexample.entity.ProductCatalog;


import exception.InvalidException;
import repository.RedisRepository;

@Service
public class ProductCatalogServiceImpl implements ProductCatalogService {

	@Autowired
	private RedisRepository redisRepo;
	
	public ProductCatalog saveProduct(ProductCatalog product) {
	
		return redisRepo.save(product);
	}

	
	@CachePut(value="product", key="#pid")
	public ProductCatalog updateProduct(ProductCatalog product, Integer pid) {
		ProductCatalog p= redisRepo.findById(pid)
				 .orElseThrow(() -> new InvalidException("Invoice Not Found"));
		p.setCountry(p.getCountry());
		p.setLanguageLocal(p.getLanguageLocal());
		p.setUseAuthentication(p.getUseAuthentication());
		return redisRepo.save(p);
	
	}

	@Override
     @CacheEvict(value="product", key="#pid")
	public void deleteProduct(Integer pid) {
		 ProductCatalog p = redisRepo.findById(pid) .orElseThrow(() -> new InvalidException(" Not Found"));
		  redisRepo.delete(p);
		
	}

	@Override
	@Cacheable(value="product", key="#pid")
	public ProductCatalog getOneProduct(Integer pid)
	{
		ProductCatalog productCatalog=redisRepo.findById(pid).orElseThrow(()->new InvalidException(" not found"));

		return productCatalog;
	}

	@Override
	@Cacheable(value="product")
	public List<ProductCatalog> getAllProducts() {
		
		return redisRepo.findAll();
	}
	

}
