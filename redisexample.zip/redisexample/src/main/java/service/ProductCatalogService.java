package service;
import java.util.List;

import com.example.redis.redisexample.entity.ProductCatalog;

public interface ProductCatalogService {
	
	  public ProductCatalog saveProduct(ProductCatalog product);
	    public ProductCatalog updateProduct(ProductCatalog product, Integer pid);
	    public void deleteProduct(Integer pid);
	    public ProductCatalog getOneProduct(Integer pid);
	    public List<ProductCatalog> getAllProducts();

}
