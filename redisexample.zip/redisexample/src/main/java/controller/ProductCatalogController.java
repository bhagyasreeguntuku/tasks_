package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.redis.redisexample.entity.ProductCatalog;
import java.util.List;

import service.ProductCatalogService;

@RestController
@RequestMapping("/product")
public class ProductCatalogController {
	
	@Autowired
	ProductCatalogService productCatalogService;
	
	
	@PostMapping("/saveProduct")
	public ProductCatalog saveProduct(@RequestBody ProductCatalog p)
	{
		return productCatalogService.saveProduct(p);
	}
	
	public ResponseEntity<List<ProductCatalog>> getAllProducts()
	{
		return ResponseEntity.ok(productCatalogService.getAllProducts());
		
	}
	   @GetMapping("/getOne/{id}")
	    public ProductCatalog getOneProduct(@PathVariable Integer id) {
	       return productCatalogService.getOneProduct(id);
	    }

	    @PutMapping("/modify/{id}")
	    public ProductCatalog updateProduct(@RequestBody ProductCatalog productCatalog, @PathVariable Integer id) {
	       return productCatalogService.updateProduct(productCatalog, id);
	    }

	    @DeleteMapping("/delete/{id}")
	    public String deleteProduct(@PathVariable Integer id) {
	    	productCatalogService.deleteProduct(id);
	       return "Product with id: "+id+ " Deleted !";
	    }
	
	

}
