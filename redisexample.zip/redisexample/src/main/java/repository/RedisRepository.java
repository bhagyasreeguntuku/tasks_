package repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.redis.redisexample.entity.ProductCatalog;

@Repository
public interface RedisRepository extends JpaRepository<ProductCatalog, Integer>{

}
