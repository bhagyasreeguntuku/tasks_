package com.example.redis.redisexample.entity;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class ProductCatalog {
	
	
	  	@Id
	    @GeneratedValue
	    private Integer pid;
	    private String country;
	    private String languageLocal;
	    private Boolean UseAuthentication;
		public Integer getPid() {
			return pid;
		}
		public void setPid(Integer pid) {
			this.pid = pid;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getLanguageLocal() {
			return languageLocal;
		}
		public void setLanguageLocal(String languageLocal) {
			this.languageLocal = languageLocal;
		}
		public Boolean getUseAuthentication() {
			return UseAuthentication;
		}
		public void setUseAuthentication(Boolean useAuthentication) {
			UseAuthentication = useAuthentication;
		}
	    
	    

}
