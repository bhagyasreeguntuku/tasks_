package com.example.redis.redisexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
